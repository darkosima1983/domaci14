<?php
$db = mysqli_connect("localhost", "root", "", "cars_shop");
if (mysqli_connect_error ())
{
    die ("Desila se greska prilikom konektovanja na bazu podatatak");
}
