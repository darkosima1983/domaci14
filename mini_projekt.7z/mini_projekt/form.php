<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unos Automobila</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            width: 50%;
            margin: auto;
            background: white;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        input, button {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Unesite novi model automobila</h2>
        <form action="data.php" method="POST">
            <input type="text" name="brand_car" placeholder="Proizvođač" required><br>
            <input type="text" name="model_car" placeholder="Model" required><br>
            <input type="number" name="production_year" placeholder="Godina proizvodnje" required><br>
            <input type="number" name="price" placeholder="Cena (€)" required><br>
            <button type="submit">Sačuvaj</button>
        </form>
    </div>
</body>
</html>