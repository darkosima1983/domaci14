<?php
require_once "base.php";
$query = "SELECT username, `password` FROM users";

$result = $db ->query ($query);
$username = $_POST["username"];
$password = $_POST["password"];
$log = false;
$rows = $result ->fetch_all(MYSQLI_ASSOC);
    
foreach ($rows as $row)
{
    $validUser = $row['username'];
    $validPass = $row['password'];
    if ($username == $validUser && $password == $validPass )
    {
        $log =true;
        break;
    }
    else
    {
    echo "Nismo nasli nijednog korisnika";
    }
}



if ($log)
{
    header("Location: product.php");
}
else
{
    echo "Niste validan korisnik";
    exit();
}









?>