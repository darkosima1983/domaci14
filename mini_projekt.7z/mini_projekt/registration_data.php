<?php
require_once "base.php";
//var_dump($_POST);

if ( !isset ($_POST["username"]) || empty($_POST["username"]))
{
    die ("Niste uneli korisničko ime");
}
if ( !isset ($_POST["password"]) || empty($_POST["password"]))
{
    die ("Niste uneli lozinku ");
}


$username = $_POST["username"];
$password = $_POST ["password"];






$query = "INSERT INTO users (username, `password`) VALUES ('$username','$password')";

$db-> query ($query);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    text-align: center;
}
.container {
    width: 80%;
    margin: auto;
    background: white;
    padding: 20px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
}
h1 {
    color: #333;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th, td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: left;
}
th {
    background-color: #333;
    color: white;
}
a {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #007BFF;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}
a:hover {
    background-color: #0056b3;
}
</style>
<body>
    <a href="login.php">Uspesno ste registrovali vratite se na "Pocetnu"</a>
</body>
</html>