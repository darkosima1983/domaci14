<?php
     $db = mysqli_connect("localhost", "root", "", "cars_shop");
     if (mysqli_connect_error ())
     {
         die ("Desila se greska prilikom konektovanja na bazu podatatak");
     }
     $query = "SELECT brand_car, model_car, production_year, price FROM cars";

     $result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Automobila</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #333;
            color: white;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Lista Automobila</h1>
        <table>
            <tr>
                <th>Proizvođač</th>
                <th>Model</th>
                <th>Godina</th>
                <th>Cena (€)</th>
            </tr>
            <?php
            $rows = $result ->fetch_all(MYSQLI_ASSOC);
            foreach ($rows as $row): ?>
                <tr>
                    <td><?= $row['brand_car'] ?></td>
                    <td><?= $row['model_car']?></td>
                    <td><?= $row['production_year']?></td>
                    <td><?= $row['price']?> €</td>
                </tr>
            <?php endforeach; ?>
          
        </table>
        <a href="form.php">Unesite novi model auta</a>
    </div>
</body>
</html>